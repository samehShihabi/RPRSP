#pragma once
#ifndef __fiteness_h__
#define __fiteness_h__
int fitenessValue(int Tmax);
int fitenessValue2(int Tmax);

#endif