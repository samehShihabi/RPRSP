#include "calculations.h"
#include "dispatchingRules.h"
#include "globalVariables.h"
#include "calculations.h"
#include <vector>
using namespace std;
int updatecities(int city, int airplaneSize, int day, int quarantineCapacity, int* passengersOut, int* valueOut)
{
    int currentCapacity = airplaneSize;
 //   printf("\n  before size=%d city=%d total=%d quarantine=%d", airplaneSize,city, totalCity[city], quarantineDays[city]);
 //   getchar();
    if (quarantineCapacity - (currentQuarantine[day]) < currentCapacity)
        currentCapacity = quarantineCapacity - (currentQuarantine[day]);
  //  printf("\n quarantineCapacity=%d currentCapacity=%d", quarantineCapacity,currentCapacity);
   // getchar();
    int totalLeaving = 0;
    for (int i = 0; i < numberGroups && currentCapacity>0; i++)
    {
        //    printf("\n group=%d number=%d",i, numberGroupCity[city][i]);
        //    getchar();
        if (numberGroupCity[city][i] > currentCapacity)
        {
            int leaving = 0;
            leaving = currentCapacity;
            // quarantine14[0] += leaving;
            for (int j = day; j <= day + quarantineDays[city]; j++)
                currentQuarantine[j] += leaving;
            totalLeaving += currentCapacity;
            numberGroupCity[city][i] -= currentCapacity;
            currentCapacity = 0;
            (*valueOut) += leaving * priorityValues[i];
        }
        else
        {
            int leaving = 0;
            leaving = numberGroupCity[city][i];
            // quarantine14[0] += leaving;
            for (int j = day; j <= day + 12; j++)
                currentQuarantine[j] += leaving;
            // (*currentQuarantine) += leaving;
            currentCapacity -= numberGroupCity[city][i];
            totalLeaving += numberGroupCity[city][i];
             (*valueOut) += leaving * priorityValues[i];
            numberGroupCity[city][i] = 0;

        }
        //  printf("\n group=%d number=%d", i, numberGroupCity[city][i]);
        //  getchar();
    }
    //   printf("\n total leaving=%d",totalLeaving);
    //   getchar();
  //  printf("\n before city=%d total before=%d",city, totalCity[city]);
    totalCity[city] -= totalLeaving;
    (*passengersOut) = totalLeaving;
    //   printf("\n after city=%d total before=%d", city, totalCity[city]);
    //   getchar();
    int totalNumbertemp = 0;
    for (int i = 0; i < numberCities; i++)
        totalNumbertemp += totalCity[i];
    //printf("\n city=%d leaving=%d total=%d  quarantine=%d capacity=%d", city, totalLeaving, totalCity[city], (*currentQuarantine), quarantineCapacity);
    //getchar();

    return totalNumbertemp;
}