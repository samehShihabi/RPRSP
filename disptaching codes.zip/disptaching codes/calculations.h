#pragma once



#ifndef __calculations_h__
#define __calculations_h__
#include <vector>
using namespace std;

int updatecities(int city, int airplaneSize, int day, int quarantineCapacity, int* passengersOut, int* valueOut);



#endif