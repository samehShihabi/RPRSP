#include <stdio.h>
#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>


#include <ilcplex/cplex.h>
#include <ilcplex/ilocplex.h>
using namespace std;
ILOSTLBEGIN

int fleetSize;
int airplanes[50];
int quarantine;
int Tmax;
int M = 10000000000;

void readSolution(void);

FILE* readX;
int initialX[100][100][200];

void readData(void);
FILE* caseData;
int numberCitizens;
int numberCities;
int numberGroups;
int priorities[10];
int cityGroup[100][10];
int quarantineDuation[100];
int totalCityOriginal[100];

int totalOut;


int xindices[100][100][200];
int PIndices[100][10][200];
int PcumIndices[100][10][200];
int LallIndices[100][200];
int DIndices[100][200];
int OIndices[200];

int epsilonIndices[100][200];
int airplaneCapcaityIndices[100][200];
int alphaIndices[100][10][200];


int Xindex = 0;
int counterPcum = 0;
int LallCounter = 0;
int DCounter = 0;
int Ocounter = 0;
int epsilonCounter = 0;
int Alphaindex = 0;
int AirplaneCapacityIndex = 0;

void addDVs(IloEnv env, IloModel model, IloNumVarArray x,
	IloNumVarArray P, IloNumVarArray Pcum, IloNumVarArray Lall, IloNumVarArray epsilon, IloNumVarArray alpha, IloNumVarArray D, IloNumVarArray O, int time1, int time2);




void addPequations(IloEnv env, IloModel model, IloNumVarArray P, IloNumVarArray Pcum,
	IloRangeArray  rngInitialConditionPcum, IloRangeArray  rngP);

void findingLall(IloEnv env, IloModel model, IloNumVarArray epsilon, IloExprArray airplaneCapacities,
	IloNumVarArray x, IloNumVarArray Pcum, IloRangeArray  rngEpsilon, IloNumVarArray Lall, IloRangeArray  rngLall);


void updatingPcum(IloEnv env, IloModel model, IloNumVarArray Pcum, IloNumVarArray Lall,
	IloNumVarArray alpha, IloRangeArray  rngAlphaBeta, IloRangeArray rngUpdateConstraint);

void airplaneUse(IloEnv env, IloModel model, IloNumVarArray x, IloRangeArray  rngAirplaneUse);


void findDs(IloEnv env, IloModel model, IloNumVarArray Lall, IloNumVarArray D,
	IloRangeArray  rngD, IloNumVarArray O, IloRangeArray  rngO);

void startingSolution(IloEnv env, IloModel model, IloCplex cplex,IloNumVarArray x);

void solutionOutput(IloEnv env, IloModel model, IloCplex cplex, IloNumVarArray x,
	IloNumVarArray P, IloNumVarArray Pcum, IloNumVarArray Lall, IloNumVarArray epsilon,
	IloExprArray airplaneCapacities, IloNumVarArray alpha, IloNumVarArray D, IloNumVarArray O);

ILOMIPINFOCALLBACK0(trial)
{
	double val = getBestObjValue();
	double gap = getMIPRelativeGap();
	double timeS = getStartTime();
	double timeE = getCplexTime();
	int opt = getIncumbentObjValue();
	double timeDif = (timeE - timeS) / 60;
	if (timeDif > 2000)
		printf(" \n hi  val=%f gap=%f timeS=%f timeE=%f timeD=%f", val, gap, timeS, timeE, timeDif);
	if (gap < 0.5 )
	{
		printf("\n in call back val=%f best obj=%d", val, opt);
		getchar();
		abort();

	}
	//getchar();
}

void main()
{
	readData();
	printf("\n end of reading data");
	getchar();
	IloEnv   env;
	IloModel model(env);
	IloNumVarArray x(env);
	IloNumVarArray P(env, 0);
	IloNumVarArray Pcum(env, 0);
	IloNumVarArray D(env, 0);
	IloNumVarArray O(env, 0);
	IloNumVarArray alpha(env);
	//	IloNumVarArray beta(env);
	IloNumVarArray epsilon(env);
	IloNumVarArray Lall(env, 0);


	IloRangeArray  rngInitialConditionPcum(env);
	IloRangeArray  rngP(env);
	IloRangeArray  rngEpsilon(env);
	IloRangeArray  rngLall(env);
	IloRangeArray  rngAlphaBeta(env);
	IloRangeArray rngUpdateConstraint(env);
	IloRangeArray  rngAirplaneUse(env);
	IloRangeArray  rngD(env);
	IloRangeArray  rngO(env);
	IloExprArray airplaneCapacities(env);
	Tmax = 130;
	addDVs(env, model, x, P, Pcum, Lall, epsilon, alpha, D, O, 0, Tmax);
	printf("\n 1");
	getchar();
	addPequations(env, model, P, Pcum, rngInitialConditionPcum, rngP);
	printf("\n 2");
	getchar();
	findingLall(env, model, epsilon, airplaneCapacities, x, Pcum, rngEpsilon, Lall, rngLall);
	printf("\n 3");
	getchar();
	updatingPcum(env, model, Pcum, Lall, alpha, rngAlphaBeta, rngUpdateConstraint);
	printf("\n 4");
	getchar();
	airplaneUse(env, model, x, rngAirplaneUse);
	printf("\n 5");
	getchar();
//	findDs(env, model, Lall, D, rngD, O, rngO);
	printf("\n 6");
	getchar();
	IloExpr objExpression(env);
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = 1; t < Tmax; t++)
			{
				int index = PIndices[i][j][t];
				//	printf("\n i=%d j=%d t=%d index=%d", i, j, t, index);
				//	getchar();
				objExpression += priorities[j] * P[index];
			}
		}
	}
//	cout << "objective=" << objExpression;
	printf("\n 6");
//	getchar();
//	getchar();
	model.add(IloMinimize(env, objExpression));
	IloCplex cplex(model);
	cplex.use(trial(env));
	readSolution();
	startingSolution(env, model,cplex, x);
	solutionOutput(env, model, cplex, x, P, Pcum, Lall, epsilon,airplaneCapacities, alpha, D, O);
}
void startingSolution(IloEnv env, IloModel model, IloCplex cplex, IloNumVarArray x)
{
	IloNumVarArray startVar(env);
	IloNumArray startVal(env);
	for (int i = 0; i < numberCities; ++i)
		for (int j = 0; j < fleetSize; ++j) 
			for(int t=0;t<Tmax;t++)
			{
			int xLoc= xindices[i][j][t];
			startVar.add(x[xLoc]);
			startVal.add(initialX[i][j][t]);
		/*	if (initialX[i][j][t] == 1)
			{
				printf("\n flight i=%d j=%d t=%d",i,j,t);
				getchar();

			}*/
		}
	cplex.addMIPStart(startVar, startVal);
	startVal.end();
	startVar.end();



}
void solutionOutput(IloEnv env, IloModel model, IloCplex cplex, IloNumVarArray x,
	IloNumVarArray P, IloNumVarArray Pcum, IloNumVarArray Lall, IloNumVarArray epsilon,
	IloExprArray airplaneCapacities, IloNumVarArray alpha, IloNumVarArray D, IloNumVarArray O)
{
	cplex.exportModel("trial.lp");
	//	exit(0);
	cplex.solve();
	cout << "solution status" << cplex.getStatus() << endl;
	getchar();
	printf("\n objective=%f",cplex.getObjValue());
	getchar();

	for (int i = 0; i < numberCities; i++)
	{
		for (int t = 0; t < Tmax; t++)
		{
			int loc = LallIndices[i][t];
	//		printf("\n i=%d t=%d loc=%d", i, t, loc);
	//		cout << "Lall(" << i << "," << t << ")" << cplex.getValue(Lall[loc]);
	//		cout << "D(" << i << "," << t << ")" << cplex.getValue(D[loc]);
			//	getchar();
		}
	}
	/*for (int t = 0; t < Tmax; t++)
	{
		cout << "O(" << t << ")" << cplex.getValue(O[t]);
		getchar();
	}*/

	/*	for (int i = 0; i < numberCities; i++)
		{
			for (int j = 0; j < numberGroups; j++)
			{
				for (int t = 0; t < 1; t++)
				{
					int loc = alphaIndices[i][j][t];

					cout << "alpha(" << i << "," << j << "," << t << ")" << cplex.getValue(alpha[loc]);
					cout << "beta(" << i << "," << j << "," << t << ")" << cplex.getValue(beta[loc]);

					cout << "Pcum(" << i << "," << j << "," << t << ")" << cplex.getValue(Pcum[loc]) << endl;
					getchar();
				}
			}

		}*/
	for (int i = 0; i < numberCities; i++)
	{
		for (int t = 0; t < 1; t++)
		{
			int loc = epsilonIndices[i][t];
			int loc1 = airplaneCapcaityIndices[i][t];
			int loc2 = LallIndices[i][t];
			//	int loc2 = PcumIndices[i][0][0];
			printf("\n i=%d t=%d loc=%d", i, t, loc);
			//			cout << "Epsilon(" << i << "," << t << ")" << cplex.getValue(epsilon[loc])<<endl;
			//			cout << "Cap(" << i << "," << t << ")" << airplaneCapacities[loc1]<<endl;
	//		cout << "Cap(" << i << "," << t << ")" << cplex.getValue(airplaneCapacities[loc1]) << endl;
	//		cout << "Lall(" << i << "," << t << ")" << cplex.getValue(Lall[loc2]) << endl;

			//		getchar();
		}
		getchar();
	}
	
	for (int i = 0; i < numberCities; i++)
	{
		for (int k = 0; k < fleetSize; k++)
		{
			for (int t = 0; t < Tmax; t++)

			{
				int loc = xindices[i][k][t];
				int airplaneCapacity = airplanes[k];
				if (cplex.getValue(x[loc]) == 1)
				{
					cout << "x(" << i << "," << k << "," << t << ")" <<
						cplex.getValue(x[loc]) << " capacity=" << airplaneCapacity;
					//cout << "Pcum(" << i << "," << j << "," << t << ")" << cplex.getValue(Pcum[loc]) << endl;
					getchar();
				}
			}
		}

	}
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = 0; t < Tmax - 1; t++)
			{
				int loc = PcumIndices[i][j][t];
				int loc1 = PcumIndices[i][j][t + 1];
				//	cout << "P(" << i << "," << j << "," << t << ")" << cplex.getValue(P[loc]);
				cout << "Pcum(" << i << "," << j << "," << t << ")" << cplex.getValue(Pcum[loc]) << endl;
				cout << "Pcum(" << i << "," << j << "," << t + 1 << ")" << cplex.getValue(Pcum[loc1]) << endl;
				getchar();
			}
		}
	}
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = 0; t < Tmax - 1; t++)
			{
				int loc = PIndices[i][j][t];
				int loc1 = PIndices[i][j][t + 1];
				//	cout << "P(" << i << "," << j << "," << t << ")" << cplex.getValue(P[loc]);
				cout << "P(" << i << "," << j << "," << t << ")" << cplex.getValue(P[loc]) << endl;
				cout << "P(" << i << "," << j << "," << t + 1 << ")" << cplex.getValue(P[loc1]) << endl;
				getchar();
			}
		}

	}

	for (int i = 0; i < numberCities; i++)
	{
		for (int t = 0; t < 1; t++)
		{
			int loc = epsilonIndices[i][t];
			int loc1 = airplaneCapcaityIndices[i][t];
			//	int loc2 = PcumIndices[i][0][0];
			printf("\n i=%d t=%d loc=%d", i, t, loc);
			cout << "Epsilon(" << i << "," << t << ")" << cplex.getValue(epsilon[loc]);
			cout << "Cap(" << i << "," << t << ")" << airplaneCapacities[loc1];
			cout << "Cap(" << i << "," << t << ")" << cplex.getValue(airplaneCapacities[loc1]);

			getchar();
		}
	}



}
void findDs(IloEnv env, IloModel model, IloNumVarArray Lall, IloNumVarArray D, IloRangeArray  rngD,
	IloNumVarArray O, IloRangeArray  rngO)
{
	for (int i = 0; i < numberCities; i++)
	{
		for (int t = 0; t < Tmax; t++)
		{
			IloExpr Dexpr(env);
			int dind = DIndices[i][t];
			if (t < quarantineDuation[i])
			{
				Dexpr -= D[dind];
				Dexpr += 0;
			}
			else
			{
				int timeBack = t - quarantineDuation[i];
				int Lind = LallIndices[i][timeBack];
			//	printf("\n t=%d time back=%d Lind=%d duration=%d", i, t, timeBack, quarantineDuation[i]);
			//	getchar();
				Dexpr -= D[dind];
				Dexpr += Lall[Lind];
			}
			IloRange DexprConst(env, 0, Dexpr, 0);
			rngD.add(DexprConst);
		}
	}
	model.add(rngD);
	for (int t = 0; t < Tmax; t++)
	{
		IloExpr Oexpr(env);
		Oexpr += O[t];
		for (int i = 0; i < numberCities; i++)
		{
			int Lind = LallIndices[i][t];
			int Dind = DIndices[i][t];

			Oexpr -= Lall[Lind];
			Oexpr += D[Dind];

		}
		if (t > 0)
			Oexpr -= O[t - 1];
		IloRange OexprConst(env, 0, Oexpr, 0);
		rngO.add(OexprConst);
	}
	model.add(rngO);
}
void airplaneUse(IloEnv env, IloModel model, IloNumVarArray x, IloRangeArray  rngAirplaneUse)
{
	for (int k = 0; k < fleetSize; k++)
		for (int t = 0; t < Tmax; t++)
		{
			IloExpr totalflights(env);
			for (int i = 0; i < numberCities; i++)
			{
				int loc = xindices[i][k][t];
				totalflights += x[loc];
			}
			IloRange totalFlightsConst(env, 0, totalflights, 1);
			rngAirplaneUse.add(totalFlightsConst);
		}
	model.add(rngAirplaneUse);
}
void updatingPcum(IloEnv env, IloModel model, IloNumVarArray Pcum, IloNumVarArray Lall,
	IloNumVarArray alpha, IloRangeArray  rngAlphaBeta, IloRangeArray rngUpdateConstraint)
{

	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = 0; t < Tmax; t++)
			{
				int Lallind = LallIndices[i][t];
				int Alphaind = alphaIndices[i][j][t];
				int pInd = PcumIndices[i][j][t];
				IloExpr alphaExpressionI(env);
				alphaExpressionI += Lall[Lallind] - Pcum[pInd];
				alphaExpressionI -= (alpha[Alphaind] - 1) * M;
				IloRange alphaExpressionConstI(env, 0, alphaExpressionI, IloInfinity);
				rngAlphaBeta.add(alphaExpressionConstI);
				/*if (i == 1)
				{
					cout << "i=1" << alphaExpressionConstI;
					getchar();

				}*/
				IloExpr alphaExpressionII(env);
				alphaExpressionII -= Lall[Lallind] - Pcum[pInd];
				alphaExpressionII += alpha[Alphaind] * M;
				IloRange alphaExpressionConstII(env, 0, alphaExpressionII, IloInfinity);
				rngAlphaBeta.add(alphaExpressionConstII);

				rngAlphaBeta.add(alphaExpressionConstI);
				/*	if (i == 1)
					{
						cout << "i=2" << alphaExpressionConstII;
						getchar();

					}*/
					/*				IloExpr betaExpressionI(env);
									betaExpressionI += Pcum[pInd] - Lall[Lallind];
									betaExpressionI -= (beta[Alphaind] - 1) * M;
									IloRange betaExpressionConstI(env, 0, betaExpressionI, IloInfinity);
									rngAlphaBeta.add(betaExpressionConstI);*/

									/*	if (i == 1)
										{
											cout << "beta 1" << betaExpressionI;
											getchar();

										}*/

										/*	IloExpr betaExpressionII(env);
											betaExpressionII -= Pcum[pInd] - Lall[Lallind];
											betaExpressionII += beta[Alphaind] * M;
											IloRange betaExpressionConstII(env, 0, betaExpressionII, IloInfinity);
											rngAlphaBeta.add(betaExpressionConstII); */

			}
		}
	}


	model.add(rngAlphaBeta);
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
			for (int t = 0; t < Tmax - 1; t++)
			{
				int index1 = PcumIndices[i][j][t + 1];
				int index2 = PcumIndices[i][j][t];
				int Alphaind = alphaIndices[i][j][t];
				int Lallind = LallIndices[i][t];
				int Betaind = Alphaind;
				IloExpr updatePcumExpressionI(env);
				updatePcumExpressionI -= Pcum[index1];
				updatePcumExpressionI += (1 - alpha[Alphaind]) * M;
				IloRange updateConstraintI(env, 0, updatePcumExpressionI, IloInfinity);
				rngUpdateConstraint.add(updateConstraintI);
				IloExpr updatePcumExpressionII(env);
				updatePcumExpressionII += Pcum[index1];
				updatePcumExpressionII -= (alpha[Alphaind] - 1) * M;
				IloRange updateConstraintII(env, 0, updatePcumExpressionII, IloInfinity);
				rngUpdateConstraint.add(updateConstraintII);
				IloExpr updatePcumExpressionIII(env);
				updatePcumExpressionIII -= Pcum[index1];
				updatePcumExpressionIII += Pcum[index2] - Lall[Lallind] + alpha[Alphaind] * M;
				IloRange updateConstraintIII(env, 0, updatePcumExpressionIII, IloInfinity);
				rngUpdateConstraint.add(updateConstraintIII);
				IloExpr updatePcumExpressionIV(env);
				updatePcumExpressionIV += Pcum[index1];
				updatePcumExpressionIV -= Pcum[index2] - Lall[Lallind] - alpha[Alphaind] * M;
				IloRange updateConstraintIV(env, 0, updatePcumExpressionIV, IloInfinity);
				rngUpdateConstraint.add(updateConstraintIV);
			}
	}
	model.add(rngUpdateConstraint);

}
void findingLall(IloEnv env, IloModel model, IloNumVarArray epsilon, IloExprArray airplaneCapacities,
	IloNumVarArray x, IloNumVarArray Pcum, IloRangeArray  rngEpsilon, IloNumVarArray Lall, IloRangeArray  rngLall)
{

	int AirplaneCapacityIndex = 0;

	for (int i = 0; i < numberCities; i++)
	{

		for (int t = 0; t < Tmax; t++)
		{
			IloExpr airplaneExpression(env);
			for (int k = 0; k < fleetSize; k++)
			{
				int Index = xindices[i][k][t];
				//	printf("\n i=%d k=%d t=%d index=%d index2=%d",i,k,t,Index, AirplaneCapacityIndex);
				//	getchar();
				airplaneExpression += airplanes[k] * x[Index];

			}
			airplaneCapacities.add(airplaneExpression);
			airplaneCapcaityIndices[i][t] = AirplaneCapacityIndex;

			AirplaneCapacityIndex++;
		}
	}
	for (int i = 0; i < numberCities; i++)
	{
		for (int t = 0; t < Tmax; t++)
		{
			int PCindex = PcumIndices[i][numberGroups - 1][t];
			int epsilonIndex = epsilonIndices[i][t];
			int airplaneIndix = airplaneCapcaityIndices[i][t];
			IloExpr epsilonExpressionI(env);
			epsilonExpressionI += Pcum[PCindex] - airplaneCapacities[airplaneIndix];
			epsilonExpressionI -= (epsilon[epsilonIndex] - 1) * M;
			IloRange dumConstStartI(env, 0, epsilonExpressionI, IloInfinity);
			rngEpsilon.add(dumConstStartI);
			IloExpr epsilonExpressionII(env);
			epsilonExpressionII -= Pcum[PCindex] - airplaneCapacities[airplaneIndix];
			epsilonExpressionII += epsilon[epsilonIndex] * M;
			IloRange dumConstStartII(env, 0, epsilonExpressionII, IloInfinity);
			rngEpsilon.add(dumConstStartII);
		}
	}
	model.add(rngEpsilon);
	for (int i = 0; i < numberCities; i++)
	{

		for (int t = 0; t < Tmax; t++)
		{
			int locPcum = PcumIndices[i][numberGroups - 1][t];
			int locEpsilon = epsilonIndices[i][t];
			int airplaneIndix = airplaneCapcaityIndices[i][t];
			IloExpr LallExpressionI(env);
			LallExpressionI += airplaneCapacities[airplaneIndix] + (1 - epsilon[locEpsilon]) * M;
			LallExpressionI -= Lall[locEpsilon];
			IloRange LallExpressionConstI(env, 0, LallExpressionI, IloInfinity);
			rngLall.add(LallExpressionConstI);

			IloExpr LallExpressionII(env);
			LallExpressionII -= airplaneCapacities[airplaneIndix] + (epsilon[locEpsilon] - 1) * M;
			LallExpressionII += Lall[locEpsilon];
			IloRange LallExpressionConstII(env, 0, LallExpressionII, IloInfinity);
			rngLall.add(LallExpressionConstII);

			IloExpr LallExpressionIII(env);
			LallExpressionIII += Pcum[locPcum] + epsilon[locEpsilon] * M;
			LallExpressionIII -= Lall[locEpsilon];
			IloRange LallExpressionConstIII(env, 0, LallExpressionIII, IloInfinity);
			rngLall.add(LallExpressionConstIII);

			IloExpr LallExpressionIV(env);
			LallExpressionIV -= Pcum[locPcum] - epsilon[locEpsilon] * M;
			LallExpressionIV += Lall[locEpsilon];
			IloRange LallExpressionConstIV(env, 0, LallExpressionIV, IloInfinity);
			rngLall.add(LallExpressionConstIV);
		}
	}
	model.add(rngLall);

}

void addPequations(IloEnv env, IloModel model, IloNumVarArray P, IloNumVarArray Pcum,
	IloRangeArray  rngInitialConditionPcum, IloRangeArray  rngP)
{

	for (int i = 0; i < numberCities; i++)
	{
		//	printf("\n i=%d index=%d",i, PcumIndices[i]);
		//	getchar();
		int sum = 0;
		for (int j = 0; j < numberGroups; j++)
		{
			sum += cityGroup[i][j];
			IloExpr PcumExpr(env);
			int loc = PcumIndices[i][j][0];
			PcumExpr += Pcum[loc];
			PcumExpr -= sum;
			IloRange constraint(env, 0, PcumExpr, 0);
			rngInitialConditionPcum.add(constraint);
		}
	}
	model.add(rngInitialConditionPcum);
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = 0; t < Tmax; t++)
			{
				int loc = PIndices[i][j][t];
				IloExpr Pexpression(env);
				if (j == 0)
				{
					int index = PcumIndices[i][j][t];
					Pexpression += Pcum[index];
				}
				else
				{
					int index1 = PcumIndices[i][j][t];
					int index2 = PcumIndices[i][j - 1][t];
					Pexpression += Pcum[index1] - Pcum[index2];
				}
				Pexpression -= P[loc];
				IloRange constraint(env, 0, Pexpression, 0);
				rngP.add(constraint);
			}
		}

	}
	model.add(rngP);



}


void addDVs(IloEnv env, IloModel model, IloNumVarArray x,
	IloNumVarArray P, IloNumVarArray Pcum, IloNumVarArray Lall, IloNumVarArray epsilon, IloNumVarArray alpha, IloNumVarArray D, IloNumVarArray O, int time1, int time2)
{
	printf("\n number citizens=%d number cities=%d number groups=%d", numberCitizens, numberCities, numberGroups);
	getchar();
	for (int i = 0; i < numberCities; i++)
	{
		for (int k = 0; k < fleetSize; k++)
		{
			for (int t = time1; t < time2; t++)
			{
				char name[10];
				char name1[2];
				char name2[2];
				char name3[2];
				strcpy(name, "X(");
				_itoa(i, name1, 10);
				_itoa(k, name2, 10);
				_itoa(t, name3, 10);
				strcat(name, name1);
				strcat(name, ",");
				strcat(name, name2);
				strcat(name, ",");
				strcat(name, name3);
				strcat(name, ")");
				x.add(IloNumVar(env, 0.0, 1.0, ILOINT, name));
			//	printf("\n i=%d k=%d t=%d",i,k,t);
				xindices[i][k][t] = Xindex;
				Xindex++;
			}//end of t
		}//end of k
	}//end of i
	model.add(x);

	for (int i = 0; i < numberCities; i++)
	{
		//	printf("\n i=%d index=%d",i, PcumIndices[i]);
		//	getchar();
		for (int j = 0; j < numberGroups; j++)
			for (int t = time1; t <= time2; t++)
			{
				char name[10];
				char name1[2];
				char name2[2];
				char name3[2];
				strcpy(name, "Pcum(");
				_itoa(i, name1, 10);
				_itoa(j, name2, 10);
				_itoa(t, name3, 10);
				strcat(name, name1);
				strcat(name, ",");
				strcat(name, name2);
				strcat(name, ",");
				strcat(name, name3);
				strcat(name, ")");
				Pcum.add(IloNumVar(env, 0.0, 200000, ILOFLOAT, name));
				strcpy(name, "P(");
				_itoa(i, name1, 10);
				_itoa(j, name2, 10);
				_itoa(t, name3, 10);
				strcat(name, name1);
				strcat(name, ",");
				strcat(name, name2);
				strcat(name, ",");
				strcat(name, name3);
				strcat(name, ")");
				P.add(IloNumVar(env, 0.0, 2000000, ILOFLOAT, name));
				PcumIndices[i][j][t] = counterPcum;
				PIndices[i][j][t] = counterPcum;
				counterPcum++;
			}

	}
	model.add(P);
	model.add(Pcum);

	for (int i = 0; i < numberCities; i++)
	{
		for (int t = time1; t < time2; t++)
		{
			char name[10];
			char name1[2];
			char name2[2];
			char name3[2];
			strcpy(name, "Lall(");
			_itoa(i, name1, 10);
			_itoa(t, name3, 10);
			strcat(name, name1);
			strcat(name, ",");
			strcat(name, name3);
			strcat(name, ")");
			Lall.add(IloNumVar(env, 0.0, 100000, ILOFLOAT, name));
			LallIndices[i][t] = LallCounter;
			//	printf("\n i=%d t=%d Lindex=%d", i, t, LallIndices[i][t]);
			//	getchar();
			LallCounter++;

		}

	}
	model.add(Lall);


	int epsilonCounter = 0;
	for (int i = 0; i < numberCities; i++)
	{
		for (int t = time1; t < time2; t++)
		{
			char name[10];
			char name1[2];
			char name2[2];
			char name3[2];
			strcpy(name, "epsilon(");
			_itoa(i, name1, 10);
			_itoa(t, name3, 10);
			strcat(name, name1);
			strcat(name, ",");
			strcat(name, name3);
			strcat(name, ")");
			epsilon.add(IloNumVar(env, 0.0, 1.0, ILOINT, name));
			epsilonIndices[i][t] = epsilonCounter;
			epsilonCounter++;
		}

	}
	model.add(epsilon);
	Alphaindex = 0;
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = time1; t < time2; t++)
			{
				char name[10];
				char name1[2];
				char name2[2];
				char name3[2];


				strcpy(name, "alpha(");
				_itoa(i, name1, 10);
				_itoa(j, name2, 10);
				_itoa(t, name3, 10);
				strcat(name, name1);
				strcat(name, ",");
				strcat(name, name2);
				strcat(name, ",");
				strcat(name, name3);
				strcat(name, ")");
				alpha.add(IloNumVar(env, 0.0, 1.0, ILOINT, name));

				alphaIndices[i][j][t] = Alphaindex;
				Alphaindex++;
			}//end of t
		}//end of k
	}//end of i

	model.add(alpha);


	for (int i = 0; i < numberCities; i++)
	{
		for (int t = 0; t < Tmax; t++)
		{
			char name[10];
			char name1[2];
			char name2[2];
			char name3[2];
			strcpy(name, "D(");
			_itoa(i, name1, 10);
			_itoa(t, name3, 10);
			strcat(name, name1);
			strcat(name, ",");
			strcat(name, name3);
			strcat(name, ")");
			D.add(IloNumVar(env, 0.0, 200000, ILOFLOAT, name));
			DIndices[i][t] = DCounter;
			DCounter++;
		}

	}
	model.add(D);

	for (int t = 0; t < Tmax; t++)
	{
		char name[10];

		char name3[2];
		strcpy(name, "O(");
		_itoa(t, name3, 10);
		strcat(name, ")");
		O.add(IloNumVar(env, 0.0, quarantine, ILOFLOAT, name));
		OIndices[t] = Ocounter;
		Ocounter++;
	}


	model.add(D);
}

void readSolution(void)
{
	readX= fopen("xInitialMVar.txt", "r");
	for (int i = 0; i < 100; i++)
		for (int j = 0; j < 50; j++)
			for (int k = 0; k < 200; k++)
			{
				fscanf(readX, "%d", &initialX[i][j][k]);

			/*	if (initialX[i][j][k] == 1)
				{
					printf("\n flight i=%d j=%d t=%d", i, j, k);
					getchar();

				}*/
			}


}


void readData(void)
{
	caseData = fopen("OneMillionCaseVar.txt", "r");
//	caseData = fopen("returnCasesJordan0.txt", "r");
	fscanf(caseData, "%d", &numberCitizens);
	fscanf(caseData, "%d", &numberCities);
	fscanf(caseData, "%d", &numberGroups);
	printf("\n number citizens=%d number cities=%d number groups=%d", numberCitizens, numberCities, numberGroups);
	getchar();
	for (int i = 0; i < numberGroups; i++)
		fscanf(caseData, "%d", &priorities[i]);
	for (int i = 0; i < numberCities; i++)
	{
		totalCityOriginal[i] = 0;
		int dum;
		fscanf(caseData, "%d", &dum);
		for (int j = 0; j < numberGroups; j++)
		{
			fscanf(caseData, "%d", &cityGroup[i][j]);
			totalCityOriginal[i] += cityGroup[i][j];
		}
		fscanf(caseData, "%d", &quarantineDuation[i]);
	}
	fscanf(caseData, "%d", &fleetSize);
	for(int i=0;i<fleetSize;i++)
		fscanf(caseData, "%d", &airplanes[i]);
	fscanf(caseData, "%d", &quarantine);
	printf("\n fleet size=%d", fleetSize);
	getchar();
}