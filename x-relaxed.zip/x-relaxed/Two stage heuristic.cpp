#include <stdio.h>
#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "ORmodel.h"

#include <ilcplex/cplex.h>
#include <ilcplex/ilocplex.h>
using namespace std;
ILOSTLBEGIN

void readSolution(void);

FILE* readX;
int initialX[100][100][200];
void startingSolution(IloEnv env, IloModel model, IloCplex cplex, IloNumVarArray x);

int fleetSize;
int airplanes[100];
int quarantine;
int Tmax;
int M = 1000000;

void readData(void);
FILE* caseData;
int numberCitizens;
int numberCities;
int numberGroups;
int priorities[10];
int cityGroup[100][10];
int quarantineDuation[100];
int totalCityOriginal[100];

int totalOut;

int xindices[100][100][200];
int PIndices[100][10][200];
int PcumIndices[100][10][200];
int LallIndices[100][200];
int DIndices[100][200];
int OIndices[200];

int epsilonIndices[100][200];
int airplaneCapcaityIndices[100][200];
int alphaIndices[100][10][200];
int newXstatus[100][100][200];
int Xindex = 0;
int counterPcum = 0;
int LallCounter = 0;
int DCounter = 0;
int Ocounter = 0;
int epsilonCounter = 0;
int Alphaindex = 0;
int AirplaneCapacityIndex = 0;

ILOMIPINFOCALLBACK0(trial)
{
	double val = getBestObjValue();
	double gap = getMIPRelativeGap();
	double timeS = getStartTime();
	double timeE = getCplexTime();
	int opt = getIncumbentObjValue();
	double timeDif = (timeE - timeS)/60;
	if(timeDif > 2000)
	printf(" \n hi  val=%f gap=%f timeS=%f timeE=%f timeD=%f", val, gap,timeS,timeE,timeDif);
	if (gap < 0.005 || timeDif > 3600)
	{
		printf("\n in call back val=%f best obj=%d",val,opt);
		getchar();
		abort();

	}
	//getchar();
}

void main()
{
	for (int i = 0; i < 100; i++)
		for (int j = 0; j < 100; j++)
			for (int t = 0; t < 200; t++)
				newXstatus[i][j][t] = 0;
	readData();
	IloEnv   env;
	IloModel model(env);
	IloNumVarArray x(env);
	IloNumVarArray P(env, 0);
	IloNumVarArray Pcum(env, 0);
	IloNumVarArray D(env, 0);
	IloNumVarArray O(env, 0);
	IloNumVarArray alpha(env);
	//	IloNumVarArray beta(env);
	IloNumVarArray epsilon(env);
	IloNumVarArray Lall(env, 0);


	IloRangeArray  rngInitialConditionPcum(env);
	IloRangeArray  rngP(env);
	IloRangeArray  rngEpsilon(env);
	IloRangeArray  rngLall(env);
	IloRangeArray  rngAlphaBeta(env);
	IloRangeArray rngUpdateConstraint(env);
	IloRangeArray  rngAirplaneUse(env);
	IloRangeArray  rngD(env);
	IloRangeArray  rngO(env);
	IloExprArray airplaneCapacities(env);

	IloExpr objExpression(env);
	int window = 128;
	int slider = 0;
	Tmax = 130;
	addDVs(env, model, x, P, Pcum, Lall, epsilon, alpha, D, O, 0, Tmax);
	addPequations(env, model, P, Pcum, rngInitialConditionPcum, rngP);
	findingLall2(env, model, airplaneCapacities, x, Pcum, Lall, rngLall);
	updatingPcum(env, model, Pcum, Lall, alpha, rngAlphaBeta, rngUpdateConstraint);
	airplaneUse(env, model, x, rngAirplaneUse);
	findingLall(env, model, epsilon, airplaneCapacities, x, Pcum, rngEpsilon, Lall, rngLall, 0, Tmax);
	findDs(env, model, Lall, D, rngD, O, rngO);
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = 1; t < Tmax; t++)
			{
				int index = PIndices[i][j][t];
				//	printf("\n i=%d j=%d t=%d index=%d", i, j, t, index);
				//	getchar();
				objExpression += priorities[j] * P[index];
			}
		}
	}

	model.add(IloMinimize(env, objExpression));
	IloCplex cplex(model);
	int sumOut = 0;
	do {

		for (int t = slider * window; t < slider * window + window; t++)
		{
			for (int i = 0; i < numberCities; i++)
			{

				for (int j = 0; j < numberGroups; j++)
				{
					int locAlpha = alphaIndices[i][j][t];
					//			printf("\n changed to integer i=%d k=%d t=%d", i, k, t);
					//			getchar();
					model.add(IloConversion(env, alpha[locAlpha], ILOINT));

					//	model2.add(IloConversion(env, alpha[locAlpha], ILOINT));
				}
			}

		}
		//	findingLall(env, model, epsilon, airplaneCapacities, x, Pcum, rngEpsilon, Lall, rngLall, slider * window, slider * window+window);
		for (int t = slider * window; t < slider * window + window; t++)
		{
			for (int i = 0; i < numberCities; i++)
			{
				int epsilonLoc = epsilonIndices[i][t];
				model.add(IloConversion(env, epsilon[epsilonLoc], ILOINT));

			}

		}
		IloCplex cplex(model);
		readSolution();
		startingSolution(env, model, cplex, x);
		cplex.use(trial(env));
		cplex.solve();
		cout << "solution status" << cplex.getStatus() << endl;
		//	getchar();

		printf("\n objective=%f", cplex.getObjValue());
		getchar();

		int numberI = 0;
		for (int i = 0; i < numberCities; i++)
		{
			for (int k = 0; k < fleetSize; k++)
			{
				for (int t = slider * window; t < slider * window + window; t++)
				{
					int loc = xindices[i][k][t];
					int airplaneCapacity = airplanes[k];
					//	printf("\n i=%d k=%d t=%d",i,k,t);
					//		getchar();
					if (cplex.getValue(x[loc]) > 0)
					{
						cout << "x (" << i << "," << k << "," << t << ")" << "val " << cplex.getValue(x[loc]) << endl;
						//		getchar();
						numberI++;
						newXstatus[i][k][t] = 1;
					}
					//		cout <<" RC " << cplex.getReducedCost(x[loc]) << endl;
					//		getchar();

				}
			}

		}
		//	getchar();

		printf("\n number I=%d", numberI);
		getchar();

		IloModel model2(env);
		model2.add(model);

		for(int t=0;t<Tmax;t++)
			for (int i = 0; i < numberCities; i++)
			{
			
				for (int k = 0; k < fleetSize; k++)
				{
					int loc = xindices[i][k][t];
					//			printf("\n changed to integer i=%d k=%d t=%d", i, k, t);
					//			getchar();
					if (newXstatus[i][k][t] == 1 || initialX[i][k][t]==1)
						model2.add(IloConversion(env, x[loc], ILOINT));
					else
					{
						
						IloExpr fix0(env);
						fix0 += x[loc];
						IloRange constfix0(env, 0, fix0, 0);
					//	model2.add(constfix0);
			
					}
					//	model2.add(IloConversion(env, alpha[locAlpha], ILOINT));
				}
			}

		
		IloCplex cplex2(model2);
		startingSolution(env, model2, cplex2, x);

		cplex2.solve();
		
		cout << "solution status" << cplex2.getStatus() << endl;
		//	getchar();

		cout << "solution status" << cplex2.getObjValue() << endl;
		getchar();
		//	getchar();


		int Xstatuses[1000000];
		int Estatuses[1000000];
		int Alphastatus[1000000];
		for (int i = 0; i < numberCities; i++)
		{
			for (int k = 0; k < fleetSize; k++)
			{
				for (int t = slider * window; t < slider * window + window; t++)
				{
					int loc = xindices[i][k][t];
					int airplaneCapacity = airplanes[k];
					//	printf("\n i=%d k=%d t=%d",i,k,t);
					//		getchar();
					//		cout << cplex2.getValue(x[loc]) << endl;
					//		getchar();
					if (cplex.getValue(x[loc]) > 0.9)
					{
						cout << "x 1 (" << i << "," << k << "," << t << ")" << endl;
						//getchar();
						cout << cplex.getValue(x[loc]) << " capacity=" << airplaneCapacity << endl;
						//cout << "Pcum(" << i << "," << j << "," << t << ")" << cplex.getValue(Pcum[loc]) << endl;
						Xstatuses[loc] = 1;
						/*IloExpr fix1(env);
						fix1 += x[loc];

						IloRange constfix1(env, 1, fix1, 1);
					//	model2.add(constfix1);*/

					}
					else
					{
						//		cout << "x 0(" << i << "," << k << "," << t << ")" << endl;


						Xstatuses[loc] = 0;
						/*	IloExpr fix0(env);
							fix0 += x[loc];

							IloRange constfix0(env, 0, fix0, 0);
						//	model2.add(constfix0);
							getchar(); */
					}
				}
			}

		}
		//	getchar();
		for (int i = 0; i < numberCities; i++)
		{
			for (int j = 0; j < numberGroups; j++)
			{
				for (int t = slider * window; t < slider * window + window; t++)
				{
					int locAlpha = alphaIndices[i][j][t];
					//	cout << "alpha(" << i << "," << j << "," << t << ")" << cplex.getValue(alpha[locAlpha]) << endl;
					if (cplex.getValue(alpha[locAlpha]) > 0.9)
					{

						Alphastatus[locAlpha] = 1;

					}
					else
					{

						Alphastatus[locAlpha] = 0;

					}
				}
			}
		}
		//	getchar();
		for (int i = 0; i < numberCities; i++)
		{
			for (int t = slider * window; t < slider * window + window; t++)
			{
				int loc = epsilonIndices[i][t];
				int loc1 = airplaneCapcaityIndices[i][t];
				int loc2 = LallIndices[i][t];
				int locD = DIndices[i][t];
				int locPcum = PcumIndices[i][numberGroups - 1][t];
				int locPcum2 = PcumIndices[i][numberGroups - 1][t + 1];
				//	int loc2 = PcumIndices[i][0][0];
			//	printf("\n i=%d t=%d loc=%d", i, t, loc);
			//	if (cplex2.getValue(epsilon[loc]) > 0)
				{
					//		cout << "Epsilon(" << i << "," << t << ")" << cplex.getValue(epsilon[loc]) << endl;
							//			cout << "Cap(" << i << "," << t << ")" << airplaneCapacities[loc1]<<endl;
					//		cout << "Cap(" << i << "," << t << ")" << cplex.getValue(airplaneCapacities[loc1]) << endl;
					//		cout << "Lall(" << i << "," << t << ")" << cplex.getValue(Lall[loc2]) << endl;
					//		cout << "Pcum(" << i << "," << t << ")" << cplex.getValue(Pcum[locPcum]) << endl;
					//		cout << "Pcum(" << i << "," << t + 1 << ")" << cplex.getValue(Pcum[locPcum2]) << endl;

					double val = cplex.getValue(Lall[loc2]);
					sumOut += round(val);
					//	cout << "D(" << i << "," << t << ")" << cplex.getValue(D[locD]) << endl;

				}
				if (cplex.getValue(epsilon[loc]) == 0)
					Estatuses[loc] = 0;
				if (cplex.getValue(epsilon[loc]) > 0.9)
					Estatuses[loc] = 1;
			}
		}
		//	getchar();

		for (int i = 0; i < numberCities; i++)
		{
			for (int k = 0; k < fleetSize; k++)
			{
				for (int t = slider * window; t < slider * window + window; t++)
				{
					int loc = xindices[i][k][t];
					if (Xstatuses[loc] == 1)
					{
						IloExpr fix1(env);
						fix1 += x[loc];
						IloRange constfix1(env, 1, fix1, 1);
						model.add(constfix1);
					}
					else
					{
						IloExpr fix0(env);
						fix0 += x[loc];
						IloRange constfix0(env, 0, fix0, 0);
						model.add(constfix0);
					}

				}
			}
		}
		for (int i = 0; i < numberCities; i++)
		{
			for (int j = 0; j < numberGroups; j++)
			{
				for (int t = slider * window; t < slider * window + window; t++)
				{
					int locAlpha = alphaIndices[i][j][t];
					if (Alphastatus[locAlpha] == 1)
					{
						IloExpr fix1(env);
						fix1 += alpha[locAlpha];
						IloRange constfix1(env, 1, fix1, 1);
						//	model.add(constfix1);


					}
					else
					{
						IloExpr fix0(env);
						fix0 += alpha[locAlpha];
						IloRange constfix0(env, 0, fix0, 0);
						//	model.add(constfix0);


					}
				}
			}
		}

		for (int i = 0; i < numberCities; i++)
		{


			for (int t = slider * window; t < slider * window + window; t++)
			{
				int loc = epsilonIndices[i][t];
				if (Estatuses[loc] == 1)
				{
					IloExpr fix1(env);
					fix1 += epsilon[loc];
					IloRange constfix1(env, 1, fix1, 1);
					//	model.add(constfix1);
				}
				else
				{
					IloExpr fix0(env);
					fix0 += epsilon[loc];
					IloRange constfix0(env, 0, fix0, 0);
					//	model.add(constfix0);
				}

			}

		}
		//	if (sumOut % 100 != 0)
		//	{
		printf("\n sum out=%d total out =%d \n", sumOut, totalOut);
		//	getchar();
	//	}
		slider++;
	} while (/*slider < Tmax &&*/ sumOut < totalOut);
	getchar();
}

void startingSolution(IloEnv env, IloModel model, IloCplex cplex, IloNumVarArray x)
{
	IloNumVarArray startVar(env);
	IloNumArray startVal(env);
	for (int i = 0; i < numberCities; ++i)
		for (int j = 0; j < fleetSize; ++j)
			for (int t = 0; t < Tmax; t++)
			{
				int xLoc = xindices[i][j][t];
				startVar.add(x[xLoc]);
				startVal.add(initialX[i][j][t]);
				/*	if (initialX[i][j][t] == 1)
					{
						printf("\n flight i=%d j=%d t=%d",i,j,t);
						getchar();

					}*/
			}
	cplex.addMIPStart(startVar, startVal);
	startVal.end();
	startVar.end();



}
void readSolution(void)
{
	readX = fopen("xInitialMVar.txt", "r");
	for (int i = 0; i < 100; i++)
		for (int j = 0; j < 50; j++)
			for (int k = 0; k < 200; k++)
			{
				fscanf(readX, "%d", &initialX[i][j][k]);

				/*	if (initialX[i][j][k] == 1)
					{
						printf("\n flight i=%d j=%d t=%d", i, j, k);
						getchar();

					}*/
			}


}

void readData(void)
{
	totalOut = 0;
	caseData = fopen("OneMillionCaseVar.txt", "r");
	//	caseData = fopen("returnCasesJordan14.txt", "r");
	fscanf(caseData, "%d", &numberCitizens);
	fscanf(caseData, "%d", &numberCities);
	fscanf(caseData, "%d", &numberGroups);
	printf("\n number citizens=%d number cities=%d number groups=%d", numberCitizens, numberCities, numberGroups);
	getchar();
	for (int i = 0; i < numberGroups; i++)
		fscanf(caseData, "%d", &priorities[i]);
	for (int i = 0; i < numberCities; i++)
	{
		totalCityOriginal[i] = 0;
		int dum;
		fscanf(caseData, "%d", &dum);
		for (int j = 0; j < numberGroups; j++)
		{
			fscanf(caseData, "%d", &cityGroup[i][j]);
			totalCityOriginal[i] += cityGroup[i][j];
		}
		totalOut += totalCityOriginal[i];
		fscanf(caseData, "%d", &quarantineDuation[i]);
	}
	fscanf(caseData, "%d", &fleetSize);
	for (int i = 0; i < fleetSize; i++)
		fscanf(caseData, "%d", &airplanes[i]);
	fscanf(caseData, "%d", &quarantine);
}