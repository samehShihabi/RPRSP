#include <stdio.h>
#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "ORmodel.h"

#include <ilcplex/cplex.h>
#include <ilcplex/ilocplex.h>
using namespace std;
ILOSTLBEGIN

void findDs(IloEnv env, IloModel model, IloNumVarArray Lall, IloNumVarArray D, IloRangeArray  rngD,
	IloNumVarArray O, IloRangeArray  rngO)
{
	for (int i = 0; i < numberCities; i++)
	{
		for (int t = 0; t < Tmax; t++)
		{
			IloExpr Dexpr(env);
			int dind = DIndices[i][t];
			if (t < quarantineDuation[i])
			{
				Dexpr -= D[dind];
				Dexpr += 0;

			}
			else
			{


				int timeBack = t - quarantineDuation[i];
				int Lind = LallIndices[i][timeBack];
				//	printf("\n i=%d t=%d time back=%d Lind=%d dind=%d quarantine=%d", i, t, t - quarantineDuation[i], Lind, dind, quarantineDuation[i]);
				//	getchar();

				Dexpr -= D[dind];
				Dexpr += Lall[Lind];
			}
			IloRange DexprConst(env, 0, Dexpr, 0);
			rngD.add(DexprConst);
		}
	}
	model.add(rngD);
	for (int t = 0; t < Tmax; t++)
	{
		IloExpr Oexpr(env);
		Oexpr += O[t];
		for (int i = 0; i < numberCities; i++)
		{
			int Lind = LallIndices[i][t];
			int Dind = DIndices[i][t];

			Oexpr -= Lall[Lind];
			Oexpr += D[Dind];

		}
		if (t > 0)
			Oexpr -= O[t - 1];
		IloRange OexprConst(env, 0, Oexpr, 0);
		rngO.add(OexprConst);
	}
	model.add(rngO);
}

void airplaneUse(IloEnv env, IloModel model, IloNumVarArray x, IloRangeArray  rngAirplaneUse)
{
	for (int k = 0; k < fleetSize; k++)
		for (int t = 0; t < Tmax; t++)
		{
			IloExpr totalflights(env);
			for (int i = 0; i < numberCities; i++)
			{
				int loc = xindices[i][k][t];
				totalflights += x[loc];
			}
			IloRange totalFlightsConst(env, 0, totalflights, 1);
			rngAirplaneUse.add(totalFlightsConst);
		}
	model.add(rngAirplaneUse);
}

void updatingPcum(IloEnv env, IloModel model, IloNumVarArray Pcum, IloNumVarArray Lall,
	IloNumVarArray alpha, IloRangeArray  rngAlphaBeta, IloRangeArray rngUpdateConstraint)
{

	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = 0; t < Tmax; t++)
			{
				int Lallind = LallIndices[i][t];
				int Alphaind = alphaIndices[i][j][t];
				int pInd = PcumIndices[i][j][t];
				IloExpr alphaExpressionI(env);
				alphaExpressionI += Lall[Lallind] - Pcum[pInd];
				alphaExpressionI -= (alpha[Alphaind] - 1) * M;
				IloRange alphaExpressionConstI(env, 0, alphaExpressionI, IloInfinity);
				rngAlphaBeta.add(alphaExpressionConstI);
				/*if (i == 1)
				{
					cout << "i=1" << alphaExpressionConstI;
					getchar();

				}*/
				IloExpr alphaExpressionII(env);
				alphaExpressionII -= Lall[Lallind] - Pcum[pInd];
				alphaExpressionII += alpha[Alphaind] * M;
				IloRange alphaExpressionConstII(env, 0, alphaExpressionII, IloInfinity);
				rngAlphaBeta.add(alphaExpressionConstII);


				/*	if (i == 1)
					{
						cout << "i=2" << alphaExpressionConstII;
						getchar();

					}*/
					/*				IloExpr betaExpressionI(env);
									betaExpressionI += Pcum[pInd] - Lall[Lallind];
									betaExpressionI -= (beta[Alphaind] - 1) * M;
									IloRange betaExpressionConstI(env, 0, betaExpressionI, IloInfinity);
									rngAlphaBeta.add(betaExpressionConstI);*/

									/*	if (i == 1)
										{
											cout << "beta 1" << betaExpressionI;
											getchar();

										}*/

										/*	IloExpr betaExpressionII(env);
											betaExpressionII -= Pcum[pInd] - Lall[Lallind];
											betaExpressionII += beta[Alphaind] * M;
											IloRange betaExpressionConstII(env, 0, betaExpressionII, IloInfinity);
											rngAlphaBeta.add(betaExpressionConstII); */

			}
		}
	}


	model.add(rngAlphaBeta);
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
			for (int t = 0; t < Tmax - 1; t++)
			{
				int index1 = PcumIndices[i][j][t + 1];
				int index2 = PcumIndices[i][j][t];
				int Alphaind = alphaIndices[i][j][t];
				int Lallind = LallIndices[i][t];
				int Betaind = Alphaind;
				IloExpr updatePcumExpressionI(env);
				updatePcumExpressionI -= Pcum[index1];
				updatePcumExpressionI += (1 - alpha[Alphaind]) * M;
				IloRange updateConstraintI(env, 0, updatePcumExpressionI, IloInfinity);
				rngUpdateConstraint.add(updateConstraintI);
				IloExpr updatePcumExpressionII(env);
				updatePcumExpressionII += Pcum[index1];
				updatePcumExpressionII -= (alpha[Alphaind] - 1) * M;
				IloRange updateConstraintII(env, 0, updatePcumExpressionII, IloInfinity);
				rngUpdateConstraint.add(updateConstraintII);
				IloExpr updatePcumExpressionIII(env);
				updatePcumExpressionIII -= Pcum[index1];
				updatePcumExpressionIII += Pcum[index2] - Lall[Lallind] + alpha[Alphaind] * M;
				IloRange updateConstraintIII(env, 0, updatePcumExpressionIII, IloInfinity);
				rngUpdateConstraint.add(updateConstraintIII);
				IloExpr updatePcumExpressionIV(env);
				updatePcumExpressionIV += Pcum[index1];
				updatePcumExpressionIV -= Pcum[index2] - Lall[Lallind] - alpha[Alphaind] * M;
				IloRange updateConstraintIV(env, 0, updatePcumExpressionIV, IloInfinity);
				rngUpdateConstraint.add(updateConstraintIV);
			}
	}
	model.add(rngUpdateConstraint);

}

void findingLall(IloEnv env, IloModel model, IloNumVarArray epsilon, IloExprArray airplaneCapacities,
	IloNumVarArray x, IloNumVarArray Pcum, IloRangeArray  rngEpsilon, IloNumVarArray Lall, IloRangeArray  rngLall, int start, int end)
{




	/*	int AirplaneCapacityIndex = 0;

		for (int i = 0; i < numberCities; i++)
		{

			for (int t = start; t < end; t++)
			{
				IloExpr airplaneExpression(env);
				for (int k = 0; k < fleetSize; k++)
				{
					int Index = xindices[i][k][t];
					//	printf("\n i=%d k=%d t=%d index=%d index2=%d",i,k,t,Index, AirplaneCapacityIndex);
					//	getchar();
					airplaneExpression += airplanes[k] * x[Index];

				}
				airplaneCapacities.add(airplaneExpression);
				airplaneCapcaityIndices[i][t] = AirplaneCapacityIndex;

				AirplaneCapacityIndex++;
			}
		}*/
	for (int i = 0; i < numberCities; i++)
	{
		for (int t = start; t < end; t++)
		{
			int PCindex = PcumIndices[i][numberGroups - 1][t];
			int epsilonIndex = epsilonIndices[i][t];
			int airplaneIndix = airplaneCapcaityIndices[i][t];
			IloExpr epsilonExpressionI(env);
			epsilonExpressionI += Pcum[PCindex] - airplaneCapacities[airplaneIndix];
			epsilonExpressionI -= (epsilon[epsilonIndex] - 1) * M;
			IloRange dumConstStartI(env, 0, epsilonExpressionI, IloInfinity);
			rngEpsilon.add(dumConstStartI);




			IloExpr epsilonExpressionII(env);
			epsilonExpressionII -= Pcum[PCindex] - airplaneCapacities[airplaneIndix];
			epsilonExpressionII += epsilon[epsilonIndex] * M;
			IloRange dumConstStartII(env, 0, epsilonExpressionII, IloInfinity);
			rngEpsilon.add(dumConstStartII);
		}
	}
	model.add(rngEpsilon);
	for (int i = 0; i < numberCities; i++)
	{

		for (int t = start; t < end; t++)
		{
			int locPcum = PcumIndices[i][numberGroups - 1][t];
			int locEpsilon = epsilonIndices[i][t];
			int airplaneIndix = airplaneCapcaityIndices[i][t];
			IloExpr LallExpression0(env);
			LallExpression0 += airplaneCapacities[airplaneIndix];
			LallExpression0 -= Lall[locEpsilon];
			IloRange LallExpressionConst0(env, 0, LallExpression0, IloInfinity);
			rngLall.add(LallExpressionConst0);

			IloExpr LallExpressionI(env);
			LallExpressionI += airplaneCapacities[airplaneIndix] + (1 - epsilon[locEpsilon]) * M;
			LallExpressionI -= Lall[locEpsilon];
			IloRange LallExpressionConstI(env, 0, LallExpressionI, IloInfinity);
			rngLall.add(LallExpressionConstI);

			IloExpr LallExpressionII(env);
			LallExpressionII -= airplaneCapacities[airplaneIndix] + (epsilon[locEpsilon] - 1) * M;
			LallExpressionII += Lall[locEpsilon];
			IloRange LallExpressionConstII(env, 0, LallExpressionII, IloInfinity);
			rngLall.add(LallExpressionConstII);

			IloExpr LallExpressionIII(env);
			LallExpressionIII += Pcum[locPcum] + epsilon[locEpsilon] * M;
			LallExpressionIII -= Lall[locEpsilon];
			IloRange LallExpressionConstIII(env, 0, LallExpressionIII, IloInfinity);
			rngLall.add(LallExpressionConstIII);

			IloExpr LallExpressionIV(env);
			LallExpressionIV -= Pcum[locPcum] - epsilon[locEpsilon] * M;
			LallExpressionIV += Lall[locEpsilon];
			IloRange LallExpressionConstIV(env, 0, LallExpressionIV, IloInfinity);
			rngLall.add(LallExpressionConstIV);
		}
	}
	model.add(rngLall);

}
void findingLall2(IloEnv env, IloModel model, IloExprArray airplaneCapacities,
	IloNumVarArray x, IloNumVarArray Pcum, IloNumVarArray Lall, IloRangeArray  rngLall)
{


	int AirplaneCapacityIndex = 0;

	for (int i = 0; i < numberCities; i++)
	{

		for (int t = 0; t < Tmax; t++)
		{
			IloExpr airplaneExpression(env);
			for (int k = 0; k < fleetSize; k++)
			{
				int Index = xindices[i][k][t];
				//	printf("\n i=%d k=%d t=%d index=%d index2=%d",i,k,t,Index, AirplaneCapacityIndex);
				//	getchar();
				airplaneExpression += airplanes[k] * x[Index];

			}
			airplaneCapacities.add(airplaneExpression);
			airplaneCapcaityIndices[i][t] = AirplaneCapacityIndex;

			AirplaneCapacityIndex++;
		}
	}

	for (int i = 0; i < numberCities; i++)
	{

		for (int t = 0; t < Tmax; t++)
		{
			int locPcum = PcumIndices[i][numberGroups - 1][t];
			int locLall = LallIndices[i][t];
			int airplaneIndix = airplaneCapcaityIndices[i][t];
			IloExpr LallExpression0(env);
			LallExpression0 += airplaneCapacities[airplaneIndix];
			LallExpression0 -= Lall[locLall];
			IloRange LallExpressionConst0(env, 0, LallExpression0, IloInfinity);
			rngLall.add(LallExpressionConst0);





			IloExpr LallExpressionIII(env);
			LallExpressionIII += Pcum[locPcum];
			LallExpressionIII -= Lall[locLall];
			IloRange LallExpressionConstIII(env, 0, LallExpressionIII, IloInfinity);
			rngLall.add(LallExpressionConstIII);


		}
	}
	//	model.add(rngLall);

}

void addPequations(IloEnv env, IloModel model, IloNumVarArray P, IloNumVarArray Pcum,
	IloRangeArray  rngInitialConditionPcum, IloRangeArray  rngP)
{

	for (int i = 0; i < numberCities; i++)
	{
		//	printf("\n i=%d index=%d",i, PcumIndices[i]);
		//	getchar();
		int sum = 0;
		for (int j = 0; j < numberGroups; j++)
		{
			sum += cityGroup[i][j];
			IloExpr PcumExpr(env);
			int loc = PcumIndices[i][j][0];
			PcumExpr += Pcum[loc];
			PcumExpr -= sum;
			IloRange constraint(env, 0, PcumExpr, 0);
			rngInitialConditionPcum.add(constraint);
		}
	}
	model.add(rngInitialConditionPcum);
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = 0; t < Tmax - 1; t++)
			{
				int loc = PIndices[i][j][t];
				IloExpr Pexpression(env);
				if (j == 0)
				{
					int index = PcumIndices[i][j][t];
					Pexpression += Pcum[index];
				}
				else
				{
					int index1 = PcumIndices[i][j][t];
					int index2 = PcumIndices[i][j - 1][t];
					Pexpression += Pcum[index1] - Pcum[index2];
				}
				Pexpression -= P[loc];
				IloRange constraint(env, 0, Pexpression, 0);
				rngP.add(constraint);
			}
		}

	}
	model.add(rngP);
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			int loc = PIndices[i][j][Tmax];
			IloExpr Pexpression(env);
			Pexpression -= P[loc];
			IloRange constraint(env, 0, Pexpression, 0);
			rngP.add(constraint);
		}

	}
	model.add(rngP);


}


void addDVs(IloEnv env, IloModel model, IloNumVarArray x,
	IloNumVarArray P, IloNumVarArray Pcum, IloNumVarArray Lall, IloNumVarArray epsilon, IloNumVarArray alpha, IloNumVarArray D, IloNumVarArray O, int time1, int time2)
{

	for (int i = 0; i < numberCities; i++)
	{
		for (int k = 0; k < fleetSize; k++)
		{
			for (int t = time1; t < time2; t++)
			{
				char name[10];
				char name1[2];
				char name2[2];
				char name3[2];
				strcpy(name, "X(");
				_itoa(i, name1, 10);
				_itoa(k, name2, 10);
				_itoa(t, name3, 10);
				strcat(name, name1);
				strcat(name, ",");
				strcat(name, name2);
				strcat(name, ",");
				strcat(name, name3);
				strcat(name, ")");
				x.add(IloNumVar(env, 0.0, 1.0, ILOFLOAT, name));
				xindices[i][k][t] = Xindex;
				Xindex++;
			}//end of t
		}//end of k
	}//end of i
	model.add(x);

	for (int i = 0; i < numberCities; i++)
	{
		//	printf("\n i=%d index=%d",i, PcumIndices[i]);
		//	getchar();
		for (int j = 0; j < numberGroups; j++)
			for (int t = time1; t <= time2; t++)
			{
				char name[10];
				char name1[2];
				char name2[2];
				char name3[2];
				strcpy(name, "Pcum(");
				_itoa(i, name1, 10);
				_itoa(j, name2, 10);
				_itoa(t, name3, 10);
				strcat(name, name1);
				strcat(name, ",");
				strcat(name, name2);
				strcat(name, ",");
				strcat(name, name3);
				strcat(name, ")");
				Pcum.add(IloNumVar(env, 0.0, 100000, ILOFLOAT, name));
				strcpy(name, "P(");
				_itoa(i, name1, 10);
				_itoa(j, name2, 10);
				_itoa(t, name3, 10);
				strcat(name, name1);
				strcat(name, ",");
				strcat(name, name2);
				strcat(name, ",");
				strcat(name, name3);
				strcat(name, ")");
				P.add(IloNumVar(env, 0.0, 50000, ILOFLOAT, name));
				PcumIndices[i][j][t] = counterPcum;
				PIndices[i][j][t] = counterPcum;
				counterPcum++;
			}

	}
	model.add(P);
	model.add(Pcum);

	for (int i = 0; i < numberCities; i++)
	{
		for (int t = time1; t < time2; t++)
		{
			char name[10];
			char name1[2];
			char name2[2];
			char name3[2];
			strcpy(name, "Lall(");
			_itoa(i, name1, 10);
			_itoa(t, name3, 10);
			strcat(name, name1);
			strcat(name, ",");
			strcat(name, name3);
			strcat(name, ")");
			Lall.add(IloNumVar(env, 0.0, 100000, ILOFLOAT, name));
			LallIndices[i][t] = LallCounter;
			//	printf("\n i=%d t=%d Lindex=%d", i, t, LallIndices[i][t]);
			//	getchar();
			LallCounter++;

		}

	}
	model.add(Lall);


	int epsilonCounter = 0;
	for (int i = 0; i < numberCities; i++)
	{
		for (int t = time1; t < time2; t++)
		{
			char name[10];
			char name1[2];
			char name2[2];
			char name3[2];
			strcpy(name, "epsilon(");
			_itoa(i, name1, 10);
			_itoa(t, name3, 10);
			strcat(name, name1);
			strcat(name, ",");
			strcat(name, name3);
			strcat(name, ")");
			epsilon.add(IloNumVar(env, 0.0, 1.0, ILOFLOAT, name));
			epsilonIndices[i][t] = epsilonCounter;
			epsilonCounter++;
		}

	}
	model.add(epsilon);
	Alphaindex = 0;
	for (int i = 0; i < numberCities; i++)
	{
		for (int j = 0; j < numberGroups; j++)
		{
			for (int t = time1; t < time2; t++)
			{
				char name[10];
				char name1[2];
				char name2[2];
				char name3[2];


				strcpy(name, "alpha(");
				_itoa(i, name1, 10);
				_itoa(j, name2, 10);
				_itoa(t, name3, 10);
				strcat(name, name1);
				strcat(name, ",");
				strcat(name, name2);
				strcat(name, ",");
				strcat(name, name3);
				strcat(name, ")");
				alpha.add(IloNumVar(env, 0.0, 1.0, ILOFLOAT, name));

				alphaIndices[i][j][t] = Alphaindex;
				Alphaindex++;
			}//end of t
		}//end of k
	}//end of i

	model.add(alpha);


	for (int i = 0; i < numberCities; i++)
	{
		for (int t = 0; t < Tmax; t++)
		{
			char name[10];
			char name1[2];
			char name2[2];
			char name3[2];
			strcpy(name, "D(");
			_itoa(i, name1, 10);
			_itoa(t, name3, 10);
			strcat(name, name1);
			strcat(name, ",");
			strcat(name, name3);
			strcat(name, ")");
			D.add(IloNumVar(env, 0.0, 200000, ILOFLOAT, name));
			DIndices[i][t] = DCounter;
			DCounter++;
		}

	}
	model.add(D);

	for (int t = 0; t < Tmax; t++)
	{
		char name[10];

		char name3[2];
		strcpy(name, "O(");
		_itoa(t, name3, 10);
		strcat(name, ")");
		O.add(IloNumVar(env, 0.0, quarantine, ILOFLOAT, name));
		OIndices[t] = Ocounter;
		Ocounter++;
	}


	model.add(D);
}
