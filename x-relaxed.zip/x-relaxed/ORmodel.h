#pragma once
#ifndef __ORmodel_h__
#define __ORmodel_h__
#include <ilcplex/cplex.h>
#include <ilcplex/ilocplex.h>
using namespace std;
ILOSTLBEGIN

extern int Xindex;
extern int counterPcum;
extern int LallCounter;
extern int DCounter;
extern int Ocounter;
extern int epsilonCounter;
extern int Alphaindex;
extern int AirplaneCapacityIndex;
extern int DCounter;
extern int Ocounter;

extern int fleetSize;
extern int airplanes[100];
extern int quarantine;
extern int Tmax;
extern int M;


extern int epsilonIndices[100][200];
extern int airplaneCapcaityIndices[100][200];
extern int xindices[100][100][200];
extern int PIndices[100][10][200];
extern int PcumIndices[100][10][200];
extern int LallIndices[100][200];
extern int DIndices[100][200];
extern int OIndices[200];
extern int alphaIndices[100][10][200];

extern int numberCitizens;
extern int numberCities;
extern int numberGroups;
extern int priorities[10];
extern int cityGroup[100][10];
extern int quarantineDuation[100];
extern int totalCityOriginal[100];

void addDVs(IloEnv env, IloModel model, IloNumVarArray x,
	IloNumVarArray P, IloNumVarArray Pcum, IloNumVarArray Lall, IloNumVarArray epsilon, IloNumVarArray alpha, IloNumVarArray D, IloNumVarArray O, int time1, int time2);

void addPequations(IloEnv env, IloModel model, IloNumVarArray P, IloNumVarArray Pcum,
	IloRangeArray  rngInitialConditionPcum, IloRangeArray  rngP);

void findingLall2(IloEnv env, IloModel model, IloExprArray airplaneCapacities,IloNumVarArray x, IloNumVarArray Pcum, IloNumVarArray Lall, IloRangeArray  rngLall);

void updatingPcum(IloEnv env, IloModel model, IloNumVarArray Pcum, IloNumVarArray Lall,
	IloNumVarArray alpha, IloRangeArray  rngAlphaBeta, IloRangeArray rngUpdateConstraint);
void airplaneUse(IloEnv env, IloModel model, IloNumVarArray x, IloRangeArray  rngAirplaneUse);

void findingLall(IloEnv env, IloModel model, IloNumVarArray epsilon, IloExprArray airplaneCapacities,
	IloNumVarArray x, IloNumVarArray Pcum, IloRangeArray  rngEpsilon, IloNumVarArray Lall, IloRangeArray  rngLall, int start, int end);

void findDs(IloEnv env, IloModel model, IloNumVarArray Lall, IloNumVarArray D, IloRangeArray  rngD,
	IloNumVarArray O, IloRangeArray  rngO);

#endif